# CLAUDE.md — Project Context for AI Assistants

## What is this project?
Makers Conclave Participant Status Check — a web app for NIAT (NxtWave of Innovation in Advanced Technologies) students participating in the Makers Conclave hackathon. Students enter their Participant ID and see their details (phase, status, campus, remarks).

## Architecture
- **Backend:** Express.js (plain JavaScript, no TypeScript, no build step)
- **Frontend:** Plain HTML/CSS/JS in `public/` (no React, no framework)
- **Data source:** Google Sheets via Google Service Account (NOT Replit connector)
- **No database** — all data comes from Google Sheets, cached in memory

## Origin
This app was built using the GRIT Registration Status Check Live app (a separate Replit-based project) as a reference. All critical logic was ported:
- In-memory caching with smart fallback (server/routes.js)
- Flexible case-insensitive column detection (server/config.js)
- Duplicate student ID detection and logging
- GID-based sheet tab targeting
- "Last Updated" text from a separate sheet tab
- Request logging middleware with timing
- Error resilience (falls back to cached data or sample data)

## Current State
- The Google Sheet with real data has NOT been connected yet
- Column names in `server/config.js` are placeholders — they need to be updated when the real sheet is provided
- The app runs in **demo mode** with 5 sample students (MC-001 through MC-005) when no sheet ID is configured
- The `.env` file needs to be created from `.env.example` with real credentials

## What to do when the sheet data arrives
1. User will share the Google Sheet URL or column headers
2. Update `server/config.js` — set the column name mappings to match real headers
3. Update `.env` — set `GOOGLE_SHEET_ID` and service account credentials
4. Optionally update `server/config.js` — set `dataSheetGid` if targeting a specific tab
5. Optionally update `server/config.js` — set `lastUpdatedSheetGid` if there's a timestamp tab
6. Update `public/index.html` — adjust field labels if the data has different fields than the current placeholders (Participant ID, Name, Campus, Phase, Status, Remarks)
7. Update `public/app.js` — adjust the `showResult()` function if fields change

## Key files to modify
- `server/config.js` — Column mappings and sheet settings (MOST IMPORTANT)
- `.env` — Google credentials and sheet ID
- `public/index.html` — UI labels and layout
- `public/app.js` — Frontend logic and status color mappings
- `server/routes.js` — API logic (usually doesn't need changes unless fields change)

## Embedding
This app is meant to be embedded in the Makers Conclave website (niatindia.com/makers-conclave) which is built in Framer. Embedding is done via iframe or Framer's API fetch component. CORS is already enabled for cross-origin access.

## No Replit
This project does NOT use Replit. It uses Google Service Account auth instead. It can be deployed to Vercel, Railway, Render, or any Node.js host.
