# Makers Conclave — Participant Status Check

A web app where students enter their Participant ID and see their Makers Conclave details (current phase, status, campus, remarks, etc.). Data is read from a Google Sheet — no database needed.

This app is designed to be **embedded** into the Makers Conclave website (niatindia.com/makers-conclave) via iframe.

---

## How It Works

```
Student types their ID on the website
        ↓
Frontend calls  GET /api/lookup/:id
        ↓
Backend reads data from Google Sheet (cached in memory)
        ↓
Returns JSON with: name, campus, phase, status, remarks
        ↓
Frontend displays a result card (green/yellow/red based on status)
```

---

## Project Structure

```
Makers-Conclave-Status-Check/
├── package.json              ← dependencies (express, googleapis, cors, dotenv)
├── .env.example              ← copy to .env and fill in credentials
├── .gitignore
├── server/
│   ├── index.js              ← Express server, serves API + static frontend
│   ├── routes.js             ← API endpoints (/api/lookup, /api/students, /api/refresh)
│   ├── googleSheets.js       ← Google Sheets API client (service account auth)
│   └── config.js             ← ⭐ COLUMN MAPPINGS — update when sheet is ready
└── public/
    ├── index.html            ← Dark-themed UI (matches Makers Conclave style)
    ├── style.css             ← All styles (black bg, card layout, responsive)
    └── app.js                ← Frontend search logic (fetch → display)
```

---

## Setup Instructions

### 1. Install Node.js
Download from https://nodejs.org (LTS version recommended).

### 2. Install Dependencies
```bash
cd Makers-Conclave-Status-Check
npm install
```

### 3. Set Up Google Service Account
1. Go to Google Cloud Console → Create a new project (or use existing)
2. Enable the **Google Sheets API**
3. Go to **IAM & Admin → Service Accounts** → Create a service account
4. Create a key (JSON type) — download the JSON file
5. From the JSON file, copy `client_email` and `private_key`
6. **Share your Google Sheet** with the service account email (give it Viewer access)

### 4. Create .env File
```bash
cp .env.example .env
```
Then fill in:
```
GOOGLE_SHEET_ID=your_sheet_id_from_url
GOOGLE_SERVICE_ACCOUNT_EMAIL=your-sa@your-project.iam.gserviceaccount.com
GOOGLE_PRIVATE_KEY="-----BEGIN PRIVATE KEY-----\n...\n-----END PRIVATE KEY-----\n"
PORT=3000
```

### 5. Configure Columns
Open `server/config.js` and update column names to match your sheet headers.

### 6. Run
```bash
npm run dev    # development (auto-restarts on changes)
npm start      # production
```
Visit http://localhost:3000

---

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/lookup/:studentId` | Look up a single student by ID |
| GET | `/api/students` | Get all students (for admin/debugging) |
| POST | `/api/refresh` | Force refresh cache from Google Sheet |
| GET | `/api/health` | Health check (shows cache status) |

### Lookup Response (found)
```json
{
  "found": true,
  "studentId": "MC-001",
  "studentName": "Aarav Sharma",
  "collegeName": "IIT Delhi",
  "phase": "Phase 2 - Prototyping",
  "status": "Active",
  "remarks": "",
  "lastUpdated": "2026-03-25T12:00:00.000Z",
  "lastUpdatedText": "Last updated: March 25, 2026"
}
```

### Lookup Response (not found)
```json
{
  "found": false,
  "studentId": "INVALID-ID",
  "status": "Not Found",
  "message": "No record found for this ID"
}
```

---

## Key Features (ported from GRIT Registration Status Check)

- **In-memory caching** — fetches from Google Sheets once, then serves from cache (configurable duration, default 1 hour)
- **Smart cache fallback** — if a refresh returns 0 rows, keeps the previous cached data
- **Flexible column detection** — matches headers case-insensitively with multiple name variants
- **Duplicate ID detection** — logs warnings if the sheet has duplicate student IDs
- **GID-based sheet targeting** — can target specific sheet tabs by GID (not just name)
- **Last Updated** — optionally reads a timestamp from a separate sheet tab
- **Error resilience** — falls back to sample data if Google Sheets is unreachable
- **CORS enabled** — works when embedded in external sites via iframe
- **Request logging** — logs all API requests with timing info

---

## Embedding in the Makers Conclave Site

### Option A: iframe (simplest)
```html
<iframe
  src="https://your-deployed-url.com"
  width="100%"
  height="600"
  frameborder="0"
  style="border: none; border-radius: 16px;"
></iframe>
```

### Option B: API only (designer builds UI in Framer)
The designer calls `GET /api/lookup/:id` from Framer's fetch component and renders the result natively.

---

## Deployment Options (no Replit needed)

| Platform | How |
|----------|-----|
| **Vercel** | Add a `vercel.json`, deploy via `vercel` CLI |
| **Railway** | Connect GitHub repo, auto-deploys |
| **Render** | Create a Web Service, set start command to `npm start` |
| **Any VPS** | Clone repo, `npm install`, `npm start` |

---

## Without Google Sheet (Demo Mode)

If no `GOOGLE_SHEET_ID` is set in `.env`, the app runs with **sample data** (5 fake students: MC-001 through MC-005). This is useful for testing the UI before the real sheet is ready.

---

## Reference: GRIT Registration Status Check

This app was built using the same architecture as the GRIT Registration Status Check Live app. Key logic (caching, column detection, duplicate tracking, error handling) was ported from that codebase. The main difference is:
- **GRIT** uses Replit's connector for Google Sheets auth
- **This app** uses a Google Service Account (works anywhere, not just Replit)
- **GRIT** is a React/Vite app with TypeScript
- **This app** is plain HTML/CSS/JS frontend + Node.js backend (simpler, no build step)
