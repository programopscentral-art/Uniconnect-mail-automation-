const input = document.getElementById("studentId");
const searchBtn = document.getElementById("searchBtn");
const loading = document.getElementById("loading");
const error = document.getElementById("error");
const errorMsg = document.getElementById("errorMsg");
const resultSection = document.getElementById("resultSection");
const notFoundCard = document.getElementById("notFoundCard");

// Press Enter to search
input.addEventListener("keydown", (e) => {
  if (e.key === "Enter") handleSearch();
});

async function handleSearch() {
  const id = input.value.trim();
  if (!id) return;

  resultSection.classList.add("hidden");
  notFoundCard.classList.add("hidden");
  error.classList.add("hidden");

  loading.classList.remove("hidden");
  searchBtn.disabled = true;

  try {
    const res = await fetch(`/api/lookup/${encodeURIComponent(id)}`);
    if (!res.ok) throw new Error("Request failed");
    const data = await res.json();

    if (data.found) {
      showResult(data);
    } else {
      showNotFound(id);
    }
  } catch (err) {
    errorMsg.textContent = "Unable to check status right now. Please try again later.";
    error.classList.remove("hidden");
  } finally {
    loading.classList.add("hidden");
    searchBtn.disabled = false;
  }
}

function showResult(data) {
  document.getElementById("resName").textContent = data.name || "—";
  document.getElementById("resId").textContent = data.niatId || "—";
  document.getElementById("resInstitute").textContent = data.university || data.institute || "—";

  // Team badge (show if they have a phase2 team)
  const teamBadge = document.getElementById("teamBadge");
  if (data.phase2 && data.phase2.teamName) {
    document.getElementById("teamName").textContent = data.phase2.teamName;
    const gradeEl = document.getElementById("teamRole");
    gradeEl.textContent = data.phase2.grade ? `Grade ${data.phase2.grade}` : "";
    teamBadge.classList.remove("hidden");
  } else {
    teamBadge.classList.add("hidden");
  }

  renderPhase1(data.phase1);
  renderPhase2(data.phase2, data.phase1);
  renderPhase3(data.phase3, data.phase1);

  resultSection.classList.remove("hidden");
}

function renderPhase1(phase1) {
  const card = document.getElementById("phase1Card");
  const indicator = document.getElementById("phase1Indicator");
  const badge = document.getElementById("phase1Badge");
  const scoresEl = document.getElementById("phase1Scores");

  card.className = "phase-card";
  indicator.className = "phase-indicator";

  if (!phase1) {
    card.classList.add("phase-pending");
    indicator.classList.add("pending");
    badge.textContent = "Registered";
    badge.className = "phase-status-badge badge-pending";
    scoresEl.innerHTML = '<p class="phase-note">Written exam data is not yet available.</p>';
    return;
  }

  const qualified = (phase1.qualified || "").toUpperCase();

  if (qualified === "YES") {
    card.classList.add("phase-passed");
    indicator.classList.add("passed");
    badge.textContent = "Qualified";
    badge.className = "phase-status-badge badge-passed";
  } else if (qualified === "NO") {
    card.classList.add("phase-failed");
    indicator.classList.add("failed");
    badge.textContent = "Not Qualified";
    badge.className = "phase-status-badge badge-failed";
  } else {
    card.classList.add("phase-pending");
    indicator.classList.add("pending");
    badge.textContent = "Under Review";
    badge.className = "phase-status-badge badge-pending";
  }

  const score = phase1.score != null ? phase1.score : "—";
  const resultText = qualified === "YES" ? "Qualified" : qualified === "NO" ? "Not Qualified" : "Pending";
  const resultClass = qualified === "YES" ? "text-green" : qualified === "NO" ? "text-red" : "";

  scoresEl.innerHTML = `
    <div class="score-item score-main">
      <span class="score-label">Score</span>
      <span class="score-value">${score} / 60</span>
    </div>
    <div class="score-item score-main">
      <span class="score-label">Result</span>
      <span class="score-value ${resultClass}">${resultText}</span>
    </div>
  `;
}

function renderPhase2(phase2, phase1) {
  const card = document.getElementById("phase2Card");
  const indicator = document.getElementById("phase2Indicator");
  const badge = document.getElementById("phase2Badge");
  const content = document.getElementById("phase2Content");
  const connector = document.getElementById("connector1");

  card.className = "phase-card";
  indicator.className = "phase-indicator";

  const phase1Qualified = phase1 ? (phase1.qualified || "").toUpperCase() : "";

  if (phase1Qualified !== "YES") {
    card.classList.add("phase-locked");
    indicator.classList.add("locked");
    badge.textContent = "Locked";
    badge.className = "phase-status-badge badge-locked";
    content.innerHTML = '<p class="phase-note">Qualify in Phase 1 to unlock this phase.</p>';
    connector.className = "phase-connector locked";
    return;
  }

  connector.className = "phase-connector active";

  // No phase2 data yet
  if (!phase2 || phase2.status === "In Progress") {
    card.classList.add("phase-upcoming");
    indicator.classList.add("upcoming");
    badge.textContent = "In Progress";
    badge.className = "phase-status-badge badge-upcoming";
    content.innerHTML = '<p class="phase-note">Project proposal review is in progress.</p>';
    return;
  }

  const status = (phase2.status || "").toUpperCase();

  if (status === "SELECTED") {
    card.classList.add("phase-passed");
    indicator.classList.add("passed");
    badge.textContent = "Selected";
    badge.className = "phase-status-badge badge-passed";
  } else if (status === "REJECTED") {
    card.classList.add("phase-failed");
    indicator.classList.add("failed");
    badge.textContent = "Not Selected";
    badge.className = "phase-status-badge badge-failed";
  } else {
    card.classList.add("phase-pending");
    indicator.classList.add("pending");
    badge.textContent = phase2.status || "Under Review";
    badge.className = "phase-status-badge badge-pending";
  }

  // Render detailed scores
  let html = "";

  // Total score + grade row
  html += `
    <div class="score-grid">
      <div class="score-item score-main">
        <span class="score-label">Total Score</span>
        <span class="score-value">${phase2.total || "—"} / 25</span>
      </div>
      <div class="score-item score-main">
        <span class="score-label">Grade</span>
        <span class="score-value grade-${(phase2.grade || "").toLowerCase()}">${phase2.grade || "—"}</span>
      </div>
    </div>
  `;

  // 5-category breakdown
  const categories = [
    { label: "Innovation", value: phase2.innovation },
    { label: "Feasibility", value: phase2.feasibility },
    { label: "Impact", value: phase2.impact },
    { label: "Clarity", value: phase2.clarity },
    { label: "HW / Tech Spec", value: phase2.hwTechSpec },
  ];

  html += `<div class="breakdown-grid">`;
  for (const cat of categories) {
    const val = cat.value ?? 0;
    const pct = (val / 5) * 100;
    html += `
      <div class="breakdown-item">
        <div class="breakdown-labels">
          <span class="breakdown-label">${cat.label}</span>
          <span class="breakdown-score">${val}/5</span>
        </div>
        <div class="breakdown-bar-bg">
          <div class="breakdown-bar-fill" style="width: ${pct}%"></div>
        </div>
      </div>
    `;
  }
  html += `</div>`;

  // Feedback (if available)
  if (phase2.feedback) {
    html += `
      <div class="feedback-box">
        <span class="feedback-label">Reviewer Feedback</span>
        <p class="feedback-text">${phase2.feedback}</p>
      </div>
    `;
  }

  content.innerHTML = html;
}

function renderPhase3(phase3, phase1) {
  const card = document.getElementById("phase3Card");
  const indicator = document.getElementById("phase3Indicator");
  const badge = document.getElementById("phase3Badge");
  const content = document.getElementById("phase3Content");
  const connector = document.getElementById("connector2");

  card.className = "phase-card";
  indicator.className = "phase-indicator";

  const phase1Qualified = phase1 ? (phase1.qualified || "").toUpperCase() : "";

  if (phase1Qualified !== "YES") {
    card.classList.add("phase-locked");
    indicator.classList.add("locked");
    badge.textContent = "Locked";
    badge.className = "phase-status-badge badge-locked";
    content.innerHTML = '<p class="phase-note">Complete previous phases to unlock.</p>';
    connector.className = "phase-connector locked";
    return;
  }

  connector.className = "phase-connector active";

  if (!phase3 || !phase3.status) {
    card.classList.add("phase-upcoming");
    indicator.classList.add("upcoming");
    badge.textContent = "In Progress";
    badge.className = "phase-status-badge badge-upcoming";
    content.innerHTML = '<p class="phase-note">Building project details will be updated soon.</p>';
    return;
  }

  card.classList.add("phase-pending");
  indicator.classList.add("pending");
  badge.textContent = phase3.status;
  badge.className = "phase-status-badge badge-pending";
  content.innerHTML = "";
}

function showNotFound(id) {
  document.getElementById("notFoundId").textContent = id;
  notFoundCard.classList.remove("hidden");
}
