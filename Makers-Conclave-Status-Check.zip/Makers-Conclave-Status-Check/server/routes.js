import { Router } from "express";
import { getGoogleSheetsClient } from "./googleSheets.js";
import { SHEET_CONFIG } from "./config.js";

const router = Router();

// In-memory cache
let cachedStudents = new Map();
let lastFetchTime = 0;
const CACHE_MS = SHEET_CONFIG.cacheHours * 60 * 60 * 1000;

// ---- Sample data ----
function getSampleData() {
  const samples = [
    {
      niatId: "N25H01A0001", name: "Aarav Sharma", university: "CDU (Hyderabad)",
      phase1: { score: 45, qualified: "YES" },
      phase2: {
        teamName: "CodeX", status: "Selected", grade: "A", total: 22,
        innovation: 5, feasibility: 4, impact: 5, clarity: 4, hwTechSpec: 4,
        feedback: "Great project with innovative approach.",
      },
      phase3: { status: "" },
    },
    {
      niatId: "N25H01A0002", name: "Priya Patel", university: "Aurora Deemed University (Hyderabad)",
      phase1: { score: 30, qualified: "NO" },
      phase2: null, phase3: null,
    },
  ];
  const map = new Map();
  for (const s of samples) map.set(s.niatId.toUpperCase(), s);
  return map;
}

// ---- Find column index (case-insensitive) ----
function findCol(headers, candidates) {
  for (const name of candidates) {
    const idx = headers.indexOf(name.toLowerCase());
    if (idx !== -1) return idx;
  }
  return -1;
}

// ---- Find sheet tab name by GID ----
function findSheetNameByGid(sheetsData, gid) {
  const sheet = sheetsData.find((s) => s.properties?.sheetId === gid);
  return sheet?.properties?.title || null;
}

// ---- Fetch data from both tabs ----
async function fetchFromSheet() {
  if (!SHEET_CONFIG.spreadsheetId) {
    console.log("No Google Sheet ID configured — using sample data");
    return getSampleData();
  }

  const sheets = await getGoogleSheetsClient();
  const meta = await sheets.spreadsheets.get({ spreadsheetId: SHEET_CONFIG.spreadsheetId });
  const allSheets = meta.data.sheets || [];

  const phase1SheetName = findSheetNameByGid(allSheets, SHEET_CONFIG.phase1Gid);
  const phase2SheetName = findSheetNameByGid(allSheets, SHEET_CONFIG.phase2Gid);
  console.log(`Tabs: Phase1="${phase1SheetName}", Phase2="${phase2SheetName}"`);

  const [phase1Response, phase2Response] = await Promise.all([
    phase1SheetName
      ? sheets.spreadsheets.values.get({ spreadsheetId: SHEET_CONFIG.spreadsheetId, range: phase1SheetName }).catch((e) => {
          console.warn("Failed to fetch Phase 1 tab:", e.message);
          return null;
        })
      : null,
    phase2SheetName
      ? sheets.spreadsheets.values.get({ spreadsheetId: SHEET_CONFIG.spreadsheetId, range: phase2SheetName }).catch((e) => {
          console.warn("Failed to fetch Phase 2 tab:", e.message);
          return null;
        })
      : null,
  ]);

  // ---- Parse Phase 2 (Project submission) → Map<NIAT ID upper, phase2Info> ----
  const phase2ByNiatId = new Map();

  if (phase2Response?.data?.values) {
    const rows = phase2Response.data.values;
    const headers = rows[0].map((h) => String(h).trim().toLowerCase());
    console.log("Phase 2 headers:", headers);

    const cols = SHEET_CONFIG.phase2Columns;
    const leaderIdIdx = findCol(headers, cols.leaderNiatId);
    const leaderNameIdx = findCol(headers, cols.leaderName);
    const teamNameIdx = findCol(headers, cols.teamName);
    const innovationIdx = findCol(headers, cols.innovation);
    const feasibilityIdx = findCol(headers, cols.feasibility);
    const impactIdx = findCol(headers, cols.impact);
    const clarityIdx = findCol(headers, cols.clarity);
    const hwIdx = findCol(headers, cols.hwTechSpec);
    const totalIdx = findCol(headers, cols.total);
    const gradeIdx = findCol(headers, cols.grade);
    const statusIdx = findCol(headers, cols.status);
    const feedbackIdx = findCol(headers, cols.feedback);

    if (leaderIdIdx === -1) {
      console.error("Phase 2 tab missing leader NIAT ID. Headers:", headers);
    } else {
      for (let i = 1; i < rows.length; i++) {
        const row = rows[i];
        if (!row) continue;

        const leaderId = String(row[leaderIdIdx] || "").trim();
        if (!leaderId) continue;

        const p2Data = {
          teamName: teamNameIdx !== -1 ? String(row[teamNameIdx] || "").trim() : "",
          leaderName: leaderNameIdx !== -1 ? String(row[leaderNameIdx] || "").trim() : "",
          innovation: innovationIdx !== -1 ? parseFloat(row[innovationIdx]) || 0 : 0,
          feasibility: feasibilityIdx !== -1 ? parseFloat(row[feasibilityIdx]) || 0 : 0,
          impact: impactIdx !== -1 ? parseFloat(row[impactIdx]) || 0 : 0,
          clarity: clarityIdx !== -1 ? parseFloat(row[clarityIdx]) || 0 : 0,
          hwTechSpec: hwIdx !== -1 ? parseFloat(row[hwIdx]) || 0 : 0,
          total: totalIdx !== -1 ? parseFloat(row[totalIdx]) || 0 : 0,
          grade: gradeIdx !== -1 ? String(row[gradeIdx] || "").trim() : "",
          status: statusIdx !== -1 ? String(row[statusIdx] || "").trim() : "",
          feedback: feedbackIdx !== -1 ? String(row[feedbackIdx] || "").trim() : "",
        };

        phase2ByNiatId.set(leaderId.toUpperCase(), p2Data);
      }
      console.log(`Phase 2: ${phase2ByNiatId.size} teams`);
    }
  }

  // ---- Parse Phase 1 (Attempted student) → build final student map ----
  const students = new Map();

  if (phase1Response?.data?.values) {
    const rows = phase1Response.data.values;
    const headers = rows[0].map((h) => String(h).trim().toLowerCase());
    console.log("Phase 1 headers:", headers);

    const cols = SHEET_CONFIG.phase1Columns;
    const niatIdIdx = findCol(headers, cols.niatId);
    const nameIdx = findCol(headers, cols.name);
    const uniIdx = findCol(headers, cols.university);
    const scoreIdx = findCol(headers, cols.score);
    const qualifiedIdx = findCol(headers, cols.qualified);

    if (niatIdIdx === -1) {
      console.error("Phase 1 tab missing NIAT ID column. Headers:", headers);
    } else {
      for (let i = 1; i < rows.length; i++) {
        const row = rows[i];
        if (!row) continue;

        const niatId = String(row[niatIdIdx] || "").trim();
        if (!niatId) continue;

        const name = nameIdx !== -1 ? String(row[nameIdx] || "").trim() : "";
        const university = uniIdx !== -1 ? String(row[uniIdx] || "").trim() : "";
        const scoreRaw = scoreIdx !== -1 ? String(row[scoreIdx] || "").trim() : "";
        const score = scoreRaw ? parseFloat(scoreRaw) || null : null;
        const qualified = qualifiedIdx !== -1 ? String(row[qualifiedIdx] || "").trim().toUpperCase() : "";

        // Phase 1
        const phase1 = { score, qualified };

        // Phase 2 — only for qualified students, lookup by NIAT ID
        const phase2Team = phase2ByNiatId.get(niatId.toUpperCase());
        let phase2 = null;
        if (qualified === "YES") {
          if (phase2Team) {
            phase2 = phase2Team;
          } else {
            phase2 = { status: "In Progress" };
          }
        }

        // Phase 3 — placeholder
        let phase3 = null;
        if (qualified === "YES") {
          phase3 = { status: "" };
        }

        students.set(niatId.toUpperCase(), {
          niatId,
          name,
          university,
          phase1,
          phase2,
          phase3,
        });
      }
      console.log(`Final data: ${students.size} students`);
    }
  }

  return students;
}

// ---- Get data (cached or fresh) ----
async function getStudents(forceRefresh = false) {
  const now = Date.now();
  if (!forceRefresh && cachedStudents.size > 0 && now - lastFetchTime < CACHE_MS) {
    return cachedStudents;
  }

  try {
    const fresh = await fetchFromSheet();
    if (fresh.size === 0 && cachedStudents.size > 0) {
      console.warn("Fetch returned 0 students — keeping cached data");
      return cachedStudents;
    }
    cachedStudents = fresh;
    lastFetchTime = now;
  } catch (err) {
    console.error("Error fetching sheet:", err.message);
    if (cachedStudents.size > 0) return cachedStudents;
    cachedStudents = getSampleData();
    lastFetchTime = now;
  }

  return cachedStudents;
}

// ====== API ENDPOINTS ======

router.get("/api/lookup/:niatId", async (req, res) => {
  try {
    const searchId = req.params.niatId.trim().toUpperCase();
    const students = await getStudents();
    const found = students.get(searchId);

    if (found) {
      return res.json({ found: true, ...found });
    } else {
      return res.json({ found: false, niatId: searchId });
    }
  } catch (err) {
    console.error("Lookup error:", err.message);
    return res.status(500).json({ error: "Unable to look up student. Try again later." });
  }
});

router.get("/api/health", (_req, res) => {
  res.json({
    status: "ok",
    cached: cachedStudents.size,
    lastFetch: lastFetchTime ? new Date(lastFetchTime).toISOString() : "never",
  });
});

router.post("/api/refresh", async (_req, res) => {
  try {
    const students = await getStudents(true);
    return res.json({ success: true, totalCount: students.size });
  } catch (err) {
    return res.status(500).json({ error: "Refresh failed" });
  }
});

export default router;
