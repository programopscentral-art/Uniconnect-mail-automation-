// ============================================================
// MAKERS CONCLAVE — GOOGLE SHEET CONFIGURATION
// ============================================================
// New consolidated sheet with two tabs:
//   1. "Attempted student" — NIAT ID, name, university, score, qualified
//   2. "Project submission" — team leader NIAT ID, team name, 5 category scores,
//      total/25, grade, status (Selected/Rejected), feedback
// ============================================================

export const SHEET_CONFIG = {
  // The Google Sheet ID
  spreadsheetId: process.env.GOOGLE_SHEET_ID || "",

  // --- Tab GIDs ---
  phase1Gid: 2127981343, // "Attempted student"
  phase2Gid: 1289917053, // "Project submission"

  // --- Phase 1 tab column mappings ---
  phase1Columns: {
    candidateId: ["candidate_id"],
    niatId: ["niat id"],
    name: ["name"],
    university: ["university"],
    email: ["email"],
    score: ["score"],
    qualified: ["qualified"],
  },

  // --- Phase 2 tab column mappings ---
  phase2Columns: {
    leaderName: ["team leader name"],
    leaderNiatId: ["team leader niat id"],
    contactNumber: ["contact number"],
    institute: ["institute name"],
    teamName: ["team name"],
    innovation: ["innovation /5"],
    feasibility: ["feasibility /5"],
    impact: ["impact /5"],
    clarity: ["clarity /5"],
    hwTechSpec: ["hw/tech spec /5"],
    total: ["total /25"],
    grade: ["grade"],
    status: ["status"],
    feedback: ["overall feedback"],
  },

  // Cache duration in hours
  cacheHours: 1,
};
