import "dotenv/config";
import express from "express";
import cors from "cors";
import { fileURLToPath } from "url";
import { dirname, join } from "path";
import routes from "./routes.js";

const __dirname = dirname(fileURLToPath(import.meta.url));
const app = express();

// Allow cross-origin requests (needed when embedded via iframe or called from Framer)
app.use(cors());
app.use(express.json());

// Request logging middleware (ported from GRIT)
app.use((req, res, next) => {
  const start = Date.now();
  res.on("finish", () => {
    if (req.path.startsWith("/api")) {
      const duration = Date.now() - start;
      const time = new Date().toLocaleTimeString("en-US", {
        hour: "numeric",
        minute: "2-digit",
        second: "2-digit",
        hour12: true,
      });
      console.log(`${time} [server] ${req.method} ${req.path} ${res.statusCode} in ${duration}ms`);
    }
  });
  next();
});

// Serve the frontend files
app.use(express.static(join(__dirname, "..", "public")));

// API routes
app.use(routes);

// Error handling middleware (ported from GRIT)
app.use((err, _req, res, _next) => {
  const status = err.status || err.statusCode || 500;
  const message = err.message || "Internal Server Error";
  console.error("Internal Server Error:", err);
  if (!res.headersSent) {
    res.status(status).json({ message });
  }
});

// Fallback — serve index.html for any non-API route
app.get("*", (_req, res) => {
  res.sendFile(join(__dirname, "..", "public", "index.html"));
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
